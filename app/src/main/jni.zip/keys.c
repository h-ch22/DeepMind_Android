#include <jni.h>

JNIEXPORT jstring JNICALL
Java_com_cj_deepmind_frameworks_helper_AES256Util_00024Companion_getNativeKey1(JNIEnv *env, jobject instance){
    return(*env) -> NewStringUTF(env, "COM_CJ_DEEPMIND_CJ_YJ_AES_NATIVE");

}

JNIEXPORT jstring JNICALL
Java_com_cj_deepmind_frameworks_helper_AES256Util_00024Companion_getNativeKey2(JNIEnv *env, jobject instance){
    return(*env) -> NewStringUTF(env, "COM_CJ_DEEPMIND_");
}